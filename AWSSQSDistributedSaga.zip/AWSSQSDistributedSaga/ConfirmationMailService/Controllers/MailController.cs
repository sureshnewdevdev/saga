using Amazon.SQS.Model;
using Amazon.SQS;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class ConfirmationMailController : ControllerBase
{
    private readonly IAmazonSQS _sqsClient;

    public ConfirmationMailController(IAmazonSQS sqsClient)
    {
        _sqsClient = sqsClient;
    }

    [HttpPost("send")]
    public async Task<IActionResult> SendConfirmationMail([FromBody] ConfirmationMail mail)
    {
        var message = new SendMessageRequest
        {
            QueueUrl = "https://sqs.us-east-1.amazonaws.com/329599649995/ConfirmationMailQueue", // Replace with your SQS queue URL for mail
            MessageBody = System.Text.Json.JsonSerializer.Serialize(mail)
        };

        await _sqsClient.SendMessageAsync(message);
        return Ok("Email notification sent to SQS queue.");
    }

    // Configure mail to other mail service like AWS SES, SendGrid, or others

    //[ApiController]
    //[Route("api/[controller]")]
    //public class ConfirmationMailController : ControllerBase
    //{
    //    [HttpPost("send")]
    //    public IActionResult SendConfirmationMail([FromBody] ConfirmationMail mail)
    //    {
    //        // Logic to send email using SMTP or a third-party service
    //        return Ok("Email sent directly.");
    //    }
    //}

}

public class ConfirmationMail
{
    public int OrderId { get; set; }
    public string Email { get; set; }
    public string Subject { get; set; }
    public string Body { get; set; }
}
