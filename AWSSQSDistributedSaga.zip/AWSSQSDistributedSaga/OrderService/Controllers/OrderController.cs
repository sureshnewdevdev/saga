using Amazon.SQS.Model;
using Amazon.SQS;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class OrderController : ControllerBase
{
    private readonly IAmazonSQS _sqsClient;

    public OrderController(IAmazonSQS sqsClient)
    {
        _sqsClient = sqsClient;
    }

    [HttpPost("create")]
    public async Task<IActionResult> CreateOrder([FromBody] Order order)
    {
        var message = new SendMessageRequest
        {
            QueueUrl = "https://sqs.us-east-1.amazonaws.com/329599649995/OrderQueue",
            MessageBody = System.Text.Json.JsonSerializer.Serialize(order)
        };
        await _sqsClient.SendMessageAsync(message);
        return Ok("Order created and sent to OrderQueue.");
    }
}

public class Order
{
    public int OrderId { get; set; }
    public string Product { get; set; }
    public decimal Amount { get; set; }
}
