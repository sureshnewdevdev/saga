using Amazon.Runtime;
using Amazon.SQS;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Read AWS configuration from appsettings.json
var awsOptions = builder.Configuration.GetSection("AWS").Get<AWSOptions>();

// Create and register Amazon SQS client with explicit credentials
builder.Services.AddSingleton<IAmazonSQS>(sp =>
{
    var credentials = new BasicAWSCredentials(awsOptions.AccessKey, awsOptions.SecretKey);
    var config = new AmazonSQSConfig
    {
        RegionEndpoint = Amazon.RegionEndpoint.GetBySystemName(awsOptions.Region)
    };
    return new AmazonSQSClient(credentials, config);
});

// Add Amazon SQS client to the DI container
builder.Services.AddSingleton<IAmazonSQS, AmazonSQSClient>();
// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();

public class AWSOptions
{
    public string AccessKey { get; set; }
    public string SecretKey { get; set; }
    public string Region { get; set; }
}