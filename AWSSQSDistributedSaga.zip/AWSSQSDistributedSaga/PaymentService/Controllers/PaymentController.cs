using Amazon.SQS.Model;
using Amazon.SQS;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class PaymentController : ControllerBase
{
    private readonly IAmazonSQS _sqsClient;

    public PaymentController(IAmazonSQS sqsClient)
    {
        _sqsClient = sqsClient;
    }

    [HttpPost("process")]
    public async Task<IActionResult> ProcessPayment([FromBody] Payment payment)
    {
        var message = new SendMessageRequest
        {
            QueueUrl = "https://sqs.us-east-1.amazonaws.com/329599649995/PaymentQueue",
            MessageBody = System.Text.Json.JsonSerializer.Serialize(payment)
        };
        await _sqsClient.SendMessageAsync(message);
        return Ok("Payment processed and sent to PaymentQueue.");
    }
}

public class Payment
{
    public int PaymentId { get; set; }
    public int OrderId { get; set; }
    public bool IsSuccessful { get; set; }
}
